package example;

import java.util.Scanner;

public class ArrayExample {

	public static void main(String[] args) {
		
		int n[] = new int[4];
		n[0] =331;
		n[1] =332;
		n[2] =333;
		n[3] =334;
		
		System.out.println(n[1]);
		
		for(int i=0;i<n.length;i++)
			System.out.println(n[i]);
		
		//or
		for(int d:n)
			System.out.println(d);
		
		//another way to declare loop
		int m[] = {111,22,3,4,34};
		for(int d:m)
			System.out.println(d);
		
		
		//declare empty array
		int dd[]=new int[4];
		Scanner sc =new Scanner(System.in);
		
		for(int i=0; i<4;i++)
		{
			
			System.out.println("enter data :");
			dd[i] =sc.nextInt();
		}
		
		for(int d:dd)
			System.out.println(d);
		
	}

}
