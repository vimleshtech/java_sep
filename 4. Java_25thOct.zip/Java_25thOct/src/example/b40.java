package example;

import java.util.Scanner;

public class b40 {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		int n1,n2;
		System.out.println("enter first no. : ");
		n1 = sc.nextInt();
		
		System.out.println("enter second no. : ");
		n2=sc.nextInt();
		
		int s=0;
		while(n1<=n2)
		{
			if(n1% 2==0 && n1% 3 ==0 && n1% 5 !=0 )
			{
					s=s+n1;
			}				
			n1++;
		}

		System.out.println(s);
	}

}
