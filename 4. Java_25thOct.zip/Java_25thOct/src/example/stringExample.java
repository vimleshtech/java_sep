package example;

import java.util.Scanner;


public class stringExample {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		String name,ns;
		
		System.out.println("enter data :");
		name =sc.nextLine();
		
		ns=name.toUpperCase();
		System.out.println(ns);
		
		ns=name.toLowerCase();
		System.out.println(ns);
		
		int l = name.length();
		System.out.println(l);

		ns =name.replace("a", "xy");
		System.out.println(ns);
		
		ns = name.substring(1, 4);
		System.out.println(ns);
		
		int ps = name.indexOf("ma");
		System.out.println(ps);
		
		char c = name.charAt(3);
		System.out.println(c);
		int nn =c;//convert to ascii code
		System.out.println(nn);
		
		ns = name.trim();
		System.out.println(ns);
		
		l = ns.length();
		System.out.println(l);

		ns = name.concat("sinha");
		System.out.println(ns);
		
		//
		if(name.equals("Raman"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		//
		if(name.equalsIgnoreCase("Raman"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(name.startsWith("r"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("not start with r");
		}
		//
		if(name.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
		
		//
		if(name.contains("ma"))
		{
			System.out.println("ma exist");
		}
		else
		{
			System.out.println("ma not exist");
		}
		
		//convert sentence to array
		String s[] =	name.split(" ");//char by char
		for(String d:s)
		{
			System.out.println(d);
		}
		
		
	}

}
