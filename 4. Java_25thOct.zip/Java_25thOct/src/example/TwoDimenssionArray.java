package example;

public class TwoDimenssionArray {

	public static void main(String[] args) {
	
		String s[][] = {{"raman","male"},{"monika","female"}};
		
		System.out.println(s[0][0]);
		
		for(String[] r:s)
		{
			for(String c:r)
			{
				System.out.println(c);
			}
		}

		//
		for(int i=0;i<s.length;i++)
		{
			for(int j=0; j<2;j++)
			{
				System.out.print(s[i][j]);
			}
			System.out.println();
		}
	}

}
