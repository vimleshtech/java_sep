package oopsExample;

import java.util.Scanner;

//class 	
public class emp {

	//data member
	int eid;
	String name;
	int sal;
	double hra;
	double da;
	double msal;
	double ysal;
	
		
	//functions 
	void newemp()
	{
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter eid : ");
		eid = sc.nextInt();
		
		System.out.println("enter name : ");
		name = sc.next();
		
		System.out.println("enter sal : ");
		sal = sc.nextInt();
		
	}	
	void compute()
	{
		hra  = sal*.15;
		da  = sal*.10;
		msal = sal+hra+da;
		ysal = msal*12;
		
				
	}
	void show()
	{
		System.out.println("**Employe Details***");
		System.out.println("Employee id : "+eid);
		System.out.println("Employee name : "+name);
		System.out.println("Employee msal : "+msal);
		System.out.println("Employee ysal : "+ysal);
		
	}
	
}
