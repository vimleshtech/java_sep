package oopsExample;

public class caller {

	public static void main(String[] args) {

		//create object of emp class
		emp o =new emp();
		emp o1 =new emp();
		
		o.newemp();
		o1.newemp();
		
		o.compute();
		o1.compute();
		
		o.show();
		o1.show();
		

	}

}

