package example;

public class functionExample {

	public static void main(String[] args) 
	{	
		//call to function 
		welcome();
		welcome();
		
		int a = getData();
		System.out.println(a);
		
		//call with argument 
		sum(11,2);
		sum(444,44);
		//call with argument and get output
		int b = mul(11,23);
		System.out.println(b);
		
	}
	
	//no argument no return
	public static void welcome()
	{
		System.out.println("welcome to function world.!!!!!!");
	}
	//no argument with return
	public static int getData()
	{
		int n=100;
		return n;
		
		
		
	}	
	//argument with no return
	public static void sum(int a, int b)
	{
		int c =a+b;
		System.out.println(c);
	}
	//argument with return
	public static int mul(int x, int y)
	{
		return x*y;
	}


}
