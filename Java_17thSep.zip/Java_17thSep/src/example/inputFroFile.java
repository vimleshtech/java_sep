package example;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class inputFroFile {

	public static void main(String[] args) throws IOException {

		
		//read file and convert to object(store to fr object)
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\Weekend\\17th Sep\\emp.txt");
		//read data from object stream to string 
		BufferedReader br  = new BufferedReader(fr);
		
		String data="";
		//get row count
		int rc = 0;
		
		//get word count 
		int wc = 0;
		
		//get/search particular word count in file
		int pwc = 0;
		
		while( (data = br.readLine()) !=null )
		{
			System.out.println(data);
			rc++;
			
			//split string to array
			String ar[] = data.split(" ");
			wc = wc+ ar.length;
			
			//get particular word/match word
			for(int j=0; j<ar.length;j++)
			{
				if(ar[j].equals("is"))
				{
					pwc++;
				}
			}
			
		}
		br.close();
		fr.close();
		
		System.out.println("no. of rows in file  : "+rc);
		System.out.println("no. of words ini file : "+wc);
		
		System.out.println("count of is : "+pwc);
		
	}

}
