package example;

import java.util.Scanner;

public class inputFromConsole {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		//Scanner : is class
		//s : is an object
		//new : is keyword which allocates the memory
		//System.in : system is class, and in is propties (direction)
		
		int n;
		System.out.println("enter data :");
		n = s.nextInt(); //nextInt - is function 
		
		System.out.println("you have entered : "+n);
		
	}

}
