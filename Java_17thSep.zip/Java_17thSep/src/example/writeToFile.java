package example;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class writeToFile {

	public static void main(String[] args) throws IOException {

		FileWriter fw  =new FileWriter("C:\\Users\\vkumar15\\Desktop\\Weekend\\17th Sep\\out.txt");
		BufferedWriter bw  = new BufferedWriter(fw);
		
		bw.write("s hjs gshgsf h sfsf");
		bw.newLine();
		bw.write("skhsj shsfg ghs hs");
		bw.close();
		fw.close();
		
		
		

	}

}
