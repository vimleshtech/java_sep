package example;

import java.util.Scanner;

public class exceptionEx {

	public static void main(String[] args) {
	
		
		int n,d,o;
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter data :");
		n =sc.nextInt();
		
		System.out.println("enter data :");
		d =sc.nextInt();
		try
		{					
			if(d<0)
			{
				Exception ex =new Exception("divisor cannot be less than 0");
				throw ex;
			}
			o =n/d;					
			System.out.println("output is "+o);
		}
		catch (ArithmeticException e) {
			
			System.out.println(e.toString());
		}
		catch (ArrayIndexOutOfBoundsException e) {
		
		}
		catch (Exception e) 
		{  //here Exception is class which can handle any type error
 			System.out.println("there is some thecnical issue");
		}
		
		//sum
		o =n+d;
		System.out.println("sum of two numbers : "+o);

	}

}
