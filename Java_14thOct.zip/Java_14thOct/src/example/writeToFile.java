package example;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class writeToFile {

	public static void main(String[] args) throws IOException {
		
		//create new file if file is not exit 
		//true -append data if file is already exit
		//false - overrite the data 
		FileWriter fw =new FileWriter("C:\\Users\\vkumar15\\Desktop\\out.txt",true);
		BufferedWriter bw =new BufferedWriter(fw);
				
		bw.write("hi");
		bw.newLine();
		bw.write("hello");
		bw.newLine();
		
		bw.close();
		fw.close();

	}

}
