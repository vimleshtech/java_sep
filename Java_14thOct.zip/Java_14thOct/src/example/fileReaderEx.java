package example;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class fileReaderEx {

	public static void main(String[] args) throws IOException {

		
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\1. Python Session-01.txt");
		BufferedReader br =new BufferedReader(fr);
		
		//wap to get number of line
		//wap to get no of words from file 
		int lineCount=0;
		int wordCount=0,totalWords=0;
		try
		{			
			String line="";
			
			while(  (line  = br.readLine())!=null )
			{
				String s[] =line.split(" ");
				wordCount=s.length;
				System.out.println(line);
				lineCount++;				
				totalWords+=wordCount;
			}
			System.out.println("Number of lines = "+lineCount);
			System.out.println("Number of words = "+totalWords);
			
	
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
		finally {
			br.close();
			fr.close();
		}
		
		

	}

}
