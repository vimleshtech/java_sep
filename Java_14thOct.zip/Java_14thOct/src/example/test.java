package example;

public class test {

	public static void main(String[] args) {
		
		String s[] = {"test","test2","test3"};
		
		for(String w:s)
		{
			System.out.println(w);
		}
		
		//
		for(int i=0; i<s.length;i++)
		{
			System.out.println(s[i]);
		}
		
	}

}
