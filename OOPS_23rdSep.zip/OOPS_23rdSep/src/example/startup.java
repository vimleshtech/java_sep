package example;

import java.util.Scanner;

public class startup {

	static 
	{
		System.out.println("before");
	}
	public static void main(String[] args) {
		
		users u1 =new users();
		users u2 =new users();

		System.out.println(u1);
		System.out.println(u2);
		
		
		u1.newUsers(11, "nitin");
		u2.newUsers(22, "rohit");
		
		u1.show(); // uid  = 22 name  = nitin 
		u2.show(); //uid   = 22  name = rohit
		
		//access data member or function without object
		//users.uid =11;
		System.out.println(users.uid);
		//users.name ="sjhs";//we cannot access non-static
		
		System.out.println("hi"); //println is static function 
		Scanner ss =new Scanner(System.in);
		ss.nextLine(); // nextLine() is non-static function 
		
		users.show();
		
		
	}

}
