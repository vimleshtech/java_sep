package example;

public class users {
	
	static int uid;
	//int uid;
	String uname;
	
	final int slab =100;
	
	void newUsers(int uid, String uname)
	{
		//slab = 33;
		
		this.uid =uid;
		this.uname= uname;
		System.out.println(uid);
	}
	
	static	void show() //static function cannot access non-static without object
	{
		System.out.println(uid);
		users o =new users();
		System.out.println(o.uname);
	}

}
