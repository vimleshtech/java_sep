package stringEx;

import java.util.Scanner;

public class Sexample {

	public static void main(String[] args) {

		String s;
		s ="skhsd";
		String sss="skhsjhghs";
		
		Scanner sc =new Scanner(System.in);
		System.out.println("ENTER DATA : ");
		
		String str = sc.nextLine();
		String ns;
		
		System.out.println(str);
		
		ns = str.toUpperCase();
		System.out.println(ns);
		
		ns = str.toLowerCase();
		System.out.println(ns);
		
		ns = str.replace("ma", "xy");
		System.out.println(ns);
		
		
		int l;
		l = str.length(); //count of chars incuding space
		System.out.println(l);
		
		int ps;
		ps = str.indexOf("a"); //position of a 
		System.out.println(ps);
		
		ns =str.trim(); //remove extra space
		System.out.println(ns);
		
		//raman
		char c = str.charAt(3); //return char of given position 
		System.out.println(c);
		
		
		ns = str.substring(3, 6);		
		System.out.println(ns);
		
		char cc[] = str.toCharArray();
		for(int i=0;i<cc.length;i++)
		{
			System.out.println(cc[i]);
		}
		
		//split : break the string by given seperator
		String ss[] = str.split(" ");
		for(String w:ss)
		{
			System.out.println(w);
		}
		
		//conditional function
		if(str.equalsIgnoreCase("raman sinha"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(str.equals("raman sinha"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		
		//
		if(str.contains("kumar"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		
		//
		if(str.startsWith("r"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("not start with r");
		}
		//
		if(str.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
		
		
		
		

	}

}
