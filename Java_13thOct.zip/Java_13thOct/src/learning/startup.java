package learning;

public class startup {

	public static void main(String[] args) {

		AExample o =new childClass();
		o.add(11, 22);
		o.mul(22, 3);		
		
		//or
		AExample oo =new AExample() 
		{ 	//implementation block 			
			@Override
			void mul(int a, int b) {								
			}
		};
		
		
		
	}

}
