package learning;

public abstract class AExample 
{
	int a;
	
	//abstract class-which cannot be implemented
	abstract void mul(int a, int b);
	
	//non-abstract class; body must be implemented
	void add(int a, int b)
	{
		int c ;
		c =a+b;
		System.out.println(c);
	}

}
