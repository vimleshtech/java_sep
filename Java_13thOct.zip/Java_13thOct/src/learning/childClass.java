package learning;

public class childClass extends AExample {

	@Override
	void mul(int a, int b) {

			System.out.println(a*b);
		
	}

}
