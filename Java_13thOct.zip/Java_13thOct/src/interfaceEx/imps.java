package interfaceEx;

public class imps implements ia,ib {

	@Override
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("test example..");
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
		
	}

	@Override
	public void wel() {
		// TODO Auto-generated method stub
		System.out.println("welll");
	}

	@Override
	public int mul(int a, int b) {
		// TODO Auto-generated method stub
		
		return a*b;
	}

}
