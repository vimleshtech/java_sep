package interfaceEx;

public class startup {

	public static void main(String[] args) {

		ia o=new imps();
		o.add(11, 3);
		o.add(33, 5);
		
		imps oo =new imps();
		oo.add(11, 22);
		

	}

}
