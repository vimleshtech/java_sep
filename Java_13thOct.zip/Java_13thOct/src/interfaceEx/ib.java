package interfaceEx;

public interface ib {

	void test();
	
}
