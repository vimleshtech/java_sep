package interfaceEx;

public interface ia {
	
	
	void add(int a, int b);
	void wel();
	
	int mul(int a, int b);
	
}
