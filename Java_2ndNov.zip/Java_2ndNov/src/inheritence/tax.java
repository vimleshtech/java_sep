package inheritence;

public class tax  extends compute {

	double msal(int sal)
	{
		
		double d = sal+sal*.40+sal*.20;
		return d;
		
		
	}
}
