package inheritence;

public class digicalc extends compute {

	void test()
	{
		System.out.println("test function..");
	}
}
