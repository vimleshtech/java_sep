package inheritence;

public class compute {

	void add(int a,int b)
	{
		int c =a+b;
		System.out.println(c);
	}
	
	void sub(int a, int b)
	{
		System.out.println(a-b);
	}
}
