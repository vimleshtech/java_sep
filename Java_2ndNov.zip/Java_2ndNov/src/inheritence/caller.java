package inheritence;

public class caller {

	public static void main(String[] aa)
	{
			tax t = new tax();
			t.add(11,22);
			t.sub(11,2);
			double dd = t.msal(434444);
			System.out.println(dd);
			
			///
			digicalc cc =new digicalc();
			cc.add(11, 33);
			cc.test();
			
			
	}
}
