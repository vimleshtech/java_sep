
public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		j6 j =new j6();
		j.count();
		j.rev();
		
	}

}
