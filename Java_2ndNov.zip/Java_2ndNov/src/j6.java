import java.util.Scanner;

public class j6 {

	String n,m;
	j6()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("enter data : ");
		
		n=sc.nextLine();
		System.out.println("enter data : ");
		m=sc.nextLine();
		
	}
	void rev( )
	{
			for(int i=n.length()-1;i>=0;i--)
			{
				System.out.print(n.charAt(i));
			}
			
			System.out.println();

			for(int i=m.length()-1;i>=0;i--)
			{
				System.out.print(m.charAt(i));
			}
			
	}
	void copy( )
	{
		m = n;
		System.out.println(m);
	}
	void concat1( )
	{
		String ss = m.concat(n);
		System.out.println(ss);
	}
	void count()
	{
		System.out.println(n.length());
		System.out.println(m.length());
	}
	
	
	
}
