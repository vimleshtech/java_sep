package polymorphisam;

import java.util.Scanner;

public class SavingAccount extends BankAccount {
	
	String address;
	int amt;


	void welcome()
	{
		System.out.println("child class class");
	}
	void newAccount()
	{
		//this.newAccount();
		super.newAccount(); //here super is keyword which refer to parent class data member or function 
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter address ");
		address= sc.next();
		
		System.out.println("enter amt :");
		amt = sc.nextInt();
		
		
	}
	 
	void show()
	{
		super.show();
		System.out.println("amt :"+amt);
		
		
		System.out.println("address  :"+address);
		
		
	}

}
