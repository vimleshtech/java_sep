package polymorphisam;

import java.util.Scanner;

public class BankAccount {

	int accno;
	String aname;
	String pan;

	void welcome()
	{
		System.out.println("parent class");
	}
	void newAccount()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("enter no ");
		accno = sc.nextInt();
		System.out.println("enter no ");
		aname = sc.next();
		System.out.println("enter no ");
		pan= sc.next();
		
	}
	
	void show()
	{
		System.out.println("Account no. "+accno);
		System.out.println("Account Name. "+aname);
		System.out.println("PAN. "+pan);
		
	}
	
}
