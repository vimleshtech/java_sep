package polymorphisam;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingAccount sa =new SavingAccount();
		sa.newAccount();
		sa.show();
		
		
		//overriding
		sa.welcome();
		
		BankAccount b =new BankAccount();
		b.welcome();
		
		//overriding
		b = sa;
		b.welcome(); //
		
		
	}

}
