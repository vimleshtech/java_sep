package loopExample;

public class WhileExample {

	public static void main(String[] aa) {
		
		//init 
		int i=1;
				
		//condition 
		while(i<10) {
			
			//System.out.println(i); //print and change line
			System.out.print(i); //print 
			i++; //increment   by 1			
			
		}
		
		//print in reverse order
		i =10;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
	
		//print all odd numbers between 1 to 30
		i=1;
		while(i<=30)
		{
			System.out.println(i);
			i=i+2;
		}
		
		
		//wap to get sum of all even and odd numbers betwen 1 to 100
		int se=0;
		int so =0;
		
		i =1;
		while(i<=100)
		{
			if(i%2==0)
			{
					se=se+i;
			}
			else
			{
					so=so+i;
			}
			i++;
		}
		System.out.println("sum of all even  numbers :"+se);
		System.out.println("sum of all odd numbers :"+so);
	}
}
