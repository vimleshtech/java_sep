package loopExample;

public class AdvanceLoopExample {

	public static void main(String[] args) {
	
		int n[] = {111,2,2,3,34,4,4,4};
		
		//a =10;
		
		for(int d: n)
		{
			System.out.println(d);
		}
		
		//or
		for(int i=0; i<8;i++)
		{
			System.out.println(n[i]);
		}

	}

}
