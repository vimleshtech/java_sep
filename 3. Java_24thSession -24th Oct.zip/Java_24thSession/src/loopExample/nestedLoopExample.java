package loopExample;

public class nestedLoopExample {

	public static void main(String[] args) {

		/*
		 * r=1 c =123
		 * r=2 c =123
		 * r=3 c =123
		 * r=4 c =123
		 */
		
		for(int r=1; r<5;r++)
		{
			for(int c=1; c<4;c++)
			{
				//System.out.println(c);
				System.out.print(c);
			}
			System.out.println();
			
		}

		/*
		 * 1
		 * 12
		 * 123
		 * *
		 * **
		 * ***
		 */
		
		for(int r=1; r<5;r++)
		{
			for(int c=1; c<=r;c++)
			{
				//System.out.println(c);
				System.out.print("*");
			}
			System.out.println();
			
		}

		
	}

}
