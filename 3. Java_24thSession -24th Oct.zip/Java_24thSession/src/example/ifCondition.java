package example;

import java.util.Scanner;

public class ifCondition {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		int a,b,c;
		System.out.println("1. for add 2 for sub 3 for mul");
		int ch =sc.nextInt();
		
		
		System.out.println("enter input 1 ");
		a = sc.nextInt();  //nextInt() is function of scanner calss
		
		System.out.println("enter input 2 ");
		b = sc.nextInt();
		
		String ss="11";
		
		if(ch==1 || ch ==10 && ss=="11")
		{
			c =a+b;
			System.out.println(c);
		}
		else if(ch==2)
		{
			c =a-b;
			System.out.println(c);	
		}
		else if(ch==3)
		{
			c =a*b;
			System.out.println(c);
		}
		else
		{
			System.out.println("choice didn't match");
		}

	}

}
