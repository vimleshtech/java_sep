package example;

import java.util.Scanner;

public class switchEx {

	public static void main(String[] args) {

		int day=3;  
		
		switch (day) {
		
			case 1:
				System.out.println("monday");
				break;
			case 2:
				System.out.println("tuesday");
				break;
			case 3:
				System.out.println("wednedsay");
				break;
			default:
				System.out.println("other day");
				break;
		}
		
		
		//
		Scanner sc =new Scanner(System.in);
		int a,b,c;
		System.out.println("1. for add 2 for sub 3 for mul");
		int ch =sc.nextInt();
		
		
		System.out.println("enter input 1 ");
		a = sc.nextInt();  //nextInt() is function of scanner calss
		
		System.out.println("enter input 2 ");
		b = sc.nextInt();
		
		
		switch (ch) {
		case 1:
			c =a+b;
			System.out.println(c);
			break;
		case 2:
			c =a-b;
			System.out.println(c);
			break;
		case 3:
			c =a*b;
			System.out.println(c);
			break;
			
		default:
			System.out.println("choice didn't match");
			break;
		}
		
		

	}

}
