package exceptionEx;

import java.util.InputMismatchException;
import java.util.Scanner;

public class exceptionEx {

	public static void main(String[] data)
	{
		
		Scanner sc = new Scanner(System.in);
		int n,d,o;
		
		
		try
		{
			System.out.println("enter data : ");
			n = sc.nextInt();
			
			System.out.println("enter data : ");
			d = sc.nextInt();
			
			if(d<0)
			{
				Exception ex = new Exception("Divisor cannot be less than 0 ");
				throw ex;
			}
			o= n/d;
			System.out.println("output is "+o);
			
		}
		catch (InputMismatchException e) {
			System.out.println("you have entered text value, number was exptected");
		}
		
		catch (ArithmeticException e) {
			System.out.println("Maths. error");
		}
		catch (Exception a)  //Exception is inbuilt class , and e is object 
		{
			System.out.println("There is technical error "+a);
		}		
		finally {
			System.out.println("end of block");
		}
		///
		int nn[] = {11,2,2,34};
		System.out.println(nn[1]);
		
	}
}
