package arrayEx;

public class singleDArray {

	public static void main(String[] args) {

		///Example -1
		int n[] = {111,222,90,1};//array index start from 0 index
		
		System.out.println(n); //print address of array variable
		System.out.println(n.length); //print length/size of elements
		
		//access array element by index
		System.out.println(n[1]);  //print 2nd element 
		
		//print / access all elements of array		
		for(int i=0;i<n.length;i++)
		{
			System.out.println(n[i]);
		}
		//wap to get sum of all numbers from array
		int sum=0;
		for(int i=0;i<n.length;i++)
		{
				sum = sum+ n[i];
		}
		
		System.out.println("sum of all elements : "+sum);
		
		///Example -2
		String name[] =new String[4];
		name[0] ="Raman";
		name[1] ="Ayush";
		name[2] ="Nidhi";
		name[3] ="Monika";
	
		System.out.println(name[2]); 
		
		//System.out.println(name[9]); //array out of index

	}

}
