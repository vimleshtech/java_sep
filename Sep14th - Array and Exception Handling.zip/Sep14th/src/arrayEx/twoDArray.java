package arrayEx;

public class twoDArray {

	public static void main(String[] args) {

		//4 rows and 3 cols
		int d[][] = {{1,2,3},{4,5},{5,6,7},{8,9,10}};
		
		System.out.println(d);
		System.out.println(d.length); //row lenght
		System.out.println(d[0].length); //col length of first row

		//access 2nd row , 1 col
		System.out.println(d[1][0]);
	
		///
		System.out.println("------");
		for(int i=0;i<d.length;i++)
		{
			for(int c=0; c<d[i].length;c++)
			{
				System.out.print(d[i][c]+"\t"); //print but dont change line
			}
			System.out.println(); //ln - new line 
		}
		
		///
		String emp[][]=new String[2][3];
		emp[0][0] ="101";
		emp[0][1] ="Raman";
		emp[0][2] ="Male";
		
		
		emp[1][0] ="102";
		emp[1][1] ="Monika";
		emp[1][2] ="Female";
		
		for(int i=0;i<emp.length;i++)
		{
			for(int c=0; c<emp[i].length;c++)
			{
				System.out.print(emp[i][c]+"\t"); //print but dont change line
			}
			System.out.println(); //ln - new line 
		}
		
	}

}
