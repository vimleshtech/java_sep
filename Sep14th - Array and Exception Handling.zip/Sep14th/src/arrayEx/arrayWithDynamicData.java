package arrayEx;

import java.util.Scanner;

public class arrayWithDynamicData {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		//Scanner is class 
		//sc is an object
		//new is keyword which allocates the memory
		//System.in   :here System is class, and in is properties for input 
		int s;
		System.out.println("enter size of array ");
		s = sc.nextInt();
		
		int arr[] = new int[s];
		for(int i=0; i<s; i++)
		{
			System.out.println("enter data for array index "+i);
			arr[i] = sc.nextInt();
		}
		
		
		//print
		System.out.println("you have entered :");
		for(int i=0;i<s;i++)
		{
			System.out.println(arr[i]);
		}

	}

}
