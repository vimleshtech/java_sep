package example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.SocketTimeoutException;

public class FileExample {

	public static void readData() throws IOException
	{
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\out.txt");
		BufferedReader br =new BufferedReader(fr);
		
		String  data="";
		
		
		while( (data = br.readLine())!=null )
		{
			System.out.println(data);
		}
		br.close();
		fr.close();
		
	}
	public static void writeData() throws IOException
	{
		FileWriter fw =new FileWriter("C:\\Users\\vkumar15\\Desktop\\out.txt");
		BufferedWriter bw =new BufferedWriter(fw);
		
		bw.write("hshjshgshg fshgshgsfgsfgffs");
		bw.newLine();
		bw.write("skshgfsg sh sffgsdfgs");
		bw.close();
		fw.close();
	}
	public static void main(String[] args) throws IOException {
		//writeData();
		//System.out.println("data is saved");

		readData();
		
	}

}
