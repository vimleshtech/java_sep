package example;

import java.util.Scanner;

public class TryCatchExample {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		int n,d,o;
		
		System.out.println("enter num : ");
		n =sc.nextInt();
		
		System.out.println("enter num : ");
		d =sc.nextInt();
		
		try {
				//div
				if(d<0)
				{
					Exception e =new Exception("divisor cannot be less than 0");
					throw e;
				}
				o =n/d;
				System.out.println(o);
		}
		catch (ArithmeticException e) {
		System.out.println("maths..erorr");	
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("array..erorr");	
		}
		catch (Exception err) { //here Exception is inbuilt class which works like data type
			
			System.out.println("there is some technical error :"+err);
			
		}
		finally {
			System.out.println("end of program");
		}
		//sum
			o =n+d;
		System.out.println(o);

	}

}
