package tax;

import java.net.SocketTimeoutException;

public class hello 
{
	//Global variable 
	int d=11; //instance variable
	static int m =44; //static variable
	
	public static void main(String[] abc) 
	{
		//local variable
		int a=11;
				
		System.out.println("welcome to java world...!!!");
		System.out.println(a);
		System.out.println(m); //static variable can be acces without object
		
		//System.out.println(d); //cannot be access without object
		
		hello o = new hello();
		System.out.println(o.d);

		
	}

}
