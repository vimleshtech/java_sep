package learning;

public class dataTypeEx {

	public static void main(String[] a)
	{
		byte b=2;
		short s =3333;
		int i =3433333;
		long l = 333445431;
		
		float dd =4333.444f;
		double ddd = 543333.433333;
		
		char c ='3';
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(dd);
		System.out.println(ddd);
		System.out.println(c);
		
		
		String ss ="sklhsk wsguytruvtu6t376537635653";
		System.out.println(ss);
		
		
	}
}
