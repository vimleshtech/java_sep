package learning;

public class switchEx {

	public static void main(String[] args) {

		int day=11;
		
		switch(day)
		{
			case 1:
			System.out.println("monday ");
			break;
			case 2:
				System.out.println("monday");
				break;
			case 3: 
				System.out.println("wednesday");
				break;
			case 4:
				System.out.println("thu");
				break;
			case 5:
				System.out.println("fri");
				break;
			default:
				System.out.println("weekend or other day");
				break;
				
			
		}

	}

}
