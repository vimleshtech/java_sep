package learning;

public class TestB10 {

	public static void main(String[] args) {
	
		long unit=2000;
		double mprice;
		
		if(unit<=100)
		{
			mprice=unit*0.40;
		}		
		else if (unit<=300)
		{
			mprice=40+ (unit-100)*0.50;
		}
		else
		{
			mprice=140 + (unit-300)*0.60;
		}

		System.out.println(mprice+50);
		
	}

}
