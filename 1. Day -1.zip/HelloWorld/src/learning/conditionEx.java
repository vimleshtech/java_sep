package learning;

import java.net.SocketTimeoutException;

public class conditionEx {

	public static void main(String[] args) {

		int sales;
		double tax=0;
		sales =700;
		//add sale tax if sale amount is greater than 1000
		//if condition
		if(sales>1000)
		{
			tax = sales*.10;
		}
		tax = tax + sales;
		
		System.out.println("total amount  "+tax);
		
		//if else 
		int n =12;
		//check even or odd
		if(n%2==0)
		{
			System.out.println("even no.");
		}
		else
		{
			System.out.println("odd no");
		}
		
		///ladder if else 
		int a,b,c;
		a =440;
		b =33;
		c =332;
		
		if(a>b && a>c)
		{
			System.out.println("a is gt");
		}
		else if (b>a && b>c)
		{
			System.out.println("b is gt");
		}
		else
		{
			System.out.println("c is gt");
		}

		//nested if else 
		if(a>b)
		{
			if(a>c)
				System.out.println("a is gt");
			else
				System.out.println("c is gt");
		}
		else
		{
			if(b>c)
			{
				System.out.println("b is gt");
			}
			else
			{
				System.out.println("c is gt");
			}
		}
		
	}

}
