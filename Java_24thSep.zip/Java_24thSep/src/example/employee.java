package example;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class employee {
	
	int eid;
	String name;
	int sal;
	int ysal;
	
	final int num=10;
	
	//constructor 
	employee()
	{
		System.out.println("object is created ");
	}
	employee(String country)
	{
			if(country.equals("india"))
			{
				System.out.println("welcome to guest user");
				name ="Guest User";
			}
			else
			{
				System.out.println("other coutry, message is not specified");
				name="New User";
			}
			
	}
	employee(employee e) //copy constructor 
	{
	
		name = e.name;
	}
	public void taxCal(int ysal)
	{
		this.ysal = ysal;
	}
	public void newEmployee()
	{
		//num =100; //this is allowecd
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter eid  :");
		eid = sc.nextInt();
		
		System.out.println("enter name  :");
		name = sc.next();
		
		System.out.println("enter sal  :");
		sal = sc.nextInt();
		
	}
	private void compute()
	{
		ysal = sal*12;
	}
	 void show()
	{
		compute();
		System.out.println("-----employee information -----");
		System.out.print("eid : "+eid+"\t name : "+name+"\t ysal : "+ysal);
	}
	 
	 static void test()
	 {
		 System.out.println("test");
	 }
		

}
