package example;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		employee e =new employee();//invoke to default/unparameterized constructor  
		e.newEmployee();
		e.show();

		employee ee =new employee("india");
		ee.show();
		
		employee eo =new employee(ee);
		eo.show();
	
	
		employee.test(); //static function can be called without object, with class name 
		//employee.show(); //non-static cannot be access without object
		
	}

}
