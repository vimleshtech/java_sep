package learning;

public class divisible {

	public static void main(String[] args) {
		int a=1;
		int sum=0;
		int n=10;
		
		while(a<=n)
		{
			if(a%5!=0 && a%3 ==0 && a%2 ==0)
			{
				sum += a;
			}
			a++;
		
		}
		System.out.println(sum);
		
	
	
				

	}

}
