package learning;

public class fact {

	public static void main(String[] args) {
		int i;
		int fact=1;
		int num=10;
		
		for (i=1;i<=num;i++)
			fact=fact*i;
	}
		{
		 System.out.println("factorial number");
		}

	

}
