package learning;

public class switchEx {

	public static void main(String[] args) {
	
		int day=20;
		
		switch(day)
		{
		case 1:
			System.out.println("monday");
			break; //termination of loop/condition / iteration 
		case 2:
			System.out.println("Tuesday  ");
			break;
		case 3:
			System.out.println("Wednesday ");
			break;
		case 4:
			System.out.println("Thu ");
			break;
		case 5:
			System.out.println("Fri ");
			break;
		default:
				System.out.println("either weekend or out of range");
				break;
			
			
		}

	}

}
