package learning;

public class nestedLoop {

	public static void main(String[] args) {

	/*
	 * i =0 j = 123
	 * i =1 j = 123
	 * i =2 j = 123
	 * i =3 j = 123	
	 */
		for(int i=0;i<4;i++)
		{
			for(int j=1;j<=3;j++)
			{
				System.out.print(j); 
			}
			System.out.println();
			
		}

		//
		for(int i=1;i<5;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j); 
			}
			System.out.println();
			
		}
		//
		for(int i=1;i<5;i++)
		{
			for(int j=i;j<5;j++)
			{
				System.out.print(j); 
			}
			System.out.println();
			
		}

	}

}
