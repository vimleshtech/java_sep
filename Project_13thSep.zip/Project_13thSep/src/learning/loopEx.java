package learning;

import java.net.SocketTimeoutException;

public class loopEx {

	public static void main(String[] args) {

		/*
		 * Loop : is iterator , repeation of statement
		 * Fundamental:
		 * 	 1 2 3 4 .. 100
		 * -init / start 				: 1
		 * -codition/limit 				: 100
		 * -steps/increment/decrement 	: +1
		 * 
		 * There are following types of loop:
		 * i. while
		 * ii. for
		 * iii. do while
		 * iv. advance loop  / for each	 
		 */
		
		//while loop
		int i=0;   //start / init
		while(i<5) //condition 
		{
			System.out.println(i);
			i++;  //increment   i=i+1
		}
		
		//print in reverse order 
		i =10;
		while(i>0)
		{
				System.out.println(i);
				i--;
				
		}
		
		//print odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i +=2; //i = i+2
		}

		
		//wap to get sum of all even and odd numbers between 1 to 100
		int se=0, so = 0;
		
		i =1;
		while(i<=100)
		{
			if(i%2==0)
			{
				se +=i;
			}
			else
			{
				so+=i;
			}
			i++;
		}
		
		System.out.println("sum of all odd numbers : "+so);
		System.out.println("sum of all even numbers : "+se);
		
		//for loop 
		for(int j =0; j<10; j++)
		{
			System.out.println(j);
		}
		
		//
		for(int j =10; j>0; j--)
		{
			System.out.println(j);
		}
		
		
		//
		for(int j =0; j<10; j=j+2)
		{
			System.out.println(j);
		}
		
		// do while : will execute at least one time
		// -first execute then check condition 
		i=0;
		do {
			
			System.out.println(i);
			i++;
		}while(i<0);
	
		
		//advance loop : for collection / array
		//advance loop is know as foreach , which forward only
		int n[]= {111,23,2,3,4,45};
		
		//int n =1
		
		for(int d: n)
		{
			System.out.println(d);
		}
		
	}

}
