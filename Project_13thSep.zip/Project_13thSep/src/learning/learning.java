package learning;

public class learning {

	public static void main(String[] args) {
		int sum=0;
		int i=1;
		int n=30;
		
		while(i<=n)
		{
			sum +=i;
			i++;
		}
		System.out.println(sum);
		System.out.println(sum/n);
		
	}

}
