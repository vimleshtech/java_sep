package learning;

import java.util.Scanner;

public class InputFromUser {

	public static void main(String[] args) {

		
		Scanner s = new Scanner(System.in);
		//here Scanner is inbuilt class
		//s is an object of class Scanner
		//new : is keyword which allocates the memory of class Scanner
		
		int n;
		String name;
		
		System.out.println("enter name : ");
		name = s.nextLine();
		
		System.out.println("enter data : ");
		n = s.nextInt();  //nextInt() is function 
		
		
		
		System.out.println("id is :"+n);
		System.out.println("name is : "+name);
		
				
		

	}

}
