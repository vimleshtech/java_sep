package learning;

public class qb8 {

	public static void main(String[] args) {
	
		int salary;
		double hra=0,da=0;
		
		salary =8000;
		
		if(salary>=5000 && salary<=10000)
		{
			hra  = salary*.10;
			da = salary *.05;
			
		}
		else if(salary>=10001 && salary<=15000)
		{
			hra  = salary*.15;
			da = salary *.08;
		}
		

		System.out.println(hra);
		System.out.println(da);
		
	}

}
