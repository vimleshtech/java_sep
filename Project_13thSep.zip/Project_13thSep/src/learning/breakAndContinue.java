package learning;

public class breakAndContinue {

	public static void main(String[] args) {
		// break: terminate the iteration when condition will match
		// continue : skip the current iteration when condition will match

		for(int i=1; i<=10;i++)
		{
			if(i%3 ==0)
				break;
			
			System.out.println(i);
		}
		
		//
		for(int i=1; i<=10;i++)
		{
			if(i%3 ==0)
				continue;
			
			System.out.println(i);
		}
		
	}

}
