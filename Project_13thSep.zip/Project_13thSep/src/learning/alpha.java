package learning;

public class alpha {

	public static void main(String[] args) {
	int i;
	int n=50;
	
	for(i=0;i<=50;i++)
	{
		System.out.println(i);
	}
}
	
}
	


