package oops1;

public class Caller {

	public static void main(String[] args) {
		
		Compute c = new Compute();
		//c is an object of class - Compute 
		//new : is keyword which allocates the memory of Compute class
		//Compute(): invoke to default constructor
		
		//invoke /call to function 
		c.input();
		c.calculate();
		c.show();
		
		
		//c.eid =1;

		Compute c1 = new Compute("us");
		
	
		//
		Compute c2 = new Compute(c);
		
		//
		Child cc = new Child();
		cc.add(11.33, 322.3);
		cc.add(11, 343);
		cc.add(11, 33,444);
		
		
				
	}

}
