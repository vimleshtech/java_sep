package oops1;

public class Parent {

	void add(int a, int b)
	{
		System.out.println(a+b);
	}
}
