package oops1;

import java.util.Scanner;

//clas
public class Compute {
	
	//data member or variable  // global varibale 
private	int eid;
private	String ename;
private	int sal;
private	double hra;
private	double da;
private	double total;

		//constructor 
		Compute(){
			System.out.println("welcome to class world ");
			System.out.println("there are fllowing function in this class i. input() ii. calculate() iii. show()");
		}

		//constructor with argument 
		Compute(String country) //works like function overloading 
		{
			if(country.equals("india"))
			{
				System.out.println("New User !!! Namaste");				
			}
			else 
			{
				System.out.println("Hello, How r u?");
			}
		}
		
		//copy constructor 
		Compute(Compute o)
		{
				sal = o.sal;
				System.out.println("previous object salary is "+sal);
		}
	//methods  / functions 
public	void input()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("enter id ");
		eid  = sc.nextInt();
	
		System.out.println("enter name ");
		ename  = sc.next();
		
		System.out.println("enter sal ");
		sal  = sc.nextInt();
				
	}
	
	void calculate()
	{
		hra  = sal*.40;
		da = sal*.20;
		total = hra+da+sal;
	}
	
	void show()
	{
		System.out.println("employee id : "+eid);
		System.out.println("employee name : "+ename);
		System.out.println("employee msal : "+sal);
		System.out.println("employee ysal : "+sal*12);
		
	}
}
