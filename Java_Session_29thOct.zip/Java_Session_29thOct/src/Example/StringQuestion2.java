package Example;

import java.util.Scanner;

public class StringQuestion2 {

	public static void main(String[] args) {
	
		String line;
		Scanner sc = new Scanner(System.in);
		line = sc.nextLine();
		
		//convert sentence to proper case 
		String s[] = line.split(" ");
		
		for(String w:s)
		{
			
			System.out.print(w.substring(0, 1).toUpperCase()+w.substring(1,w.length()).toLowerCase()+" ");
			
		}
		

	}

}
