package Example;

import java.util.Scanner;

public class StrignUperToLower {

	public static void main(String[] args) {
		
		String line;
		Scanner sc = new Scanner(System.in);
		line = sc.nextLine();
		
		for(int i=0; i<line.length();i++)
		{
			char c = line.charAt(i);
			int n = c;
			
			if(n>=65 && n<=91)
			{
				n =n+32;
				c =(char) n;
			}
			else if(n>=97 && n<=123)
			{
				n =n-32;
				c =(char) n;
			}
			else
			{
				c = line.charAt(i);
			}
					
			System.out.print(c);
			
			
		}
		

	}

}
