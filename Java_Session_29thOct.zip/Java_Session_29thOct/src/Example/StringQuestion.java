package Example;

import java.util.Scanner;

public class StringQuestion {

	public static void main(String[] args) {
		
		String line;
		Scanner sc = new Scanner(System.in);
		line = sc.nextLine();
				
		//count of space =14
		//countofspace =12
		//14-12=2
		int l = line.length() - line.replace(" ", "").length();
		System.out.println(l);
		
		// tab count
		l = line.length() - line.replace("\t", "").length();
		System.out.println(l);
		
		
		//line count
		l = line.length() - line.replace("\n", "").length();
		System.out.println(l);
		
		
		
		//
		int counter =0;
		for(int i=0; i<line.length();i++)
		{
			if(line.charAt(i)==' ')
				counter++;
		}
		System.out.println(counter);
		

	}

}
