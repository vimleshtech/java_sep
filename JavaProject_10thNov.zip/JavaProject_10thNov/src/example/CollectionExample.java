package example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.sound.midi.Soundbank;


class emp
{
	int eid;
	String name;
	int sal;
	
	//constructor 
	emp(int eid, String name, int sal)
	{
		this.eid = eid;
		this.name = name;
		this.sal = sal;
	}
	
}
public class CollectionExample {

	public static void main(String[] args) {
		
		
		//Example :1 
		ArrayList al = new ArrayList();
		
		al.add(111);
		al.add("askjsghfs");
		al.add(223434);
		al.add(true);
		
		System.out.println(al.size());
		al.remove(1);
		System.out.println(al.size());
		
		//read first element / value 
		System.out.println(al.get(0));
		
		//read all elements on by one
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		//Example :2 -fix type
		ArrayList<Integer> al2 = new ArrayList();
		//al2.add("skjhss");
		al2.add(1111);
		al2.add(33);
		
		
		//HashMap : is dictionary (key,value) , here key is user defined index 
		HashMap map = new HashMap();
		map.put("a","alpha");
		map.put("z","zebra");
		map.put("b","beta");
		map.put("ca","cat");
		map.put(1,"one");
		
		System.out.println(map.get("b"));
		
		
		//
		HashMap<Integer,String> map2 = new HashMap();
		
		//Generic 
		ArrayList<emp> e =new ArrayList<>();
		e.add(new emp(11,"raman",33333));
		e.add(new emp(21,"jatin",22233));
		e.add(new emp(31,"nitin",44556));
		
		for(int i=0; i<e.size();i++)
		{
			System.out.println(e.get(i).eid+"\t"+e.get(i).name);
		}
		
		//
		Iterator<emp> obj = e.iterator();		
		while(obj.hasNext())
		{
			System.out.println(obj.next().eid);
		}
	}

}
