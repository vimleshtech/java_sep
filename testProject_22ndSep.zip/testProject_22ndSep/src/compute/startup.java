package compute;

public class startup {

	public static void main(String[] args) {

		
		System.out.println("main");

		//create object of class employee
		employee e =new employee();
		employee  e1 =new employee(Keys.country);
		
		e.newEmployee();
		e1.newEmployee();
		
		
		e.compute();
		e.taxCalc();
		e.compute();
		e.taxCalc();
		
		e1.show();		
		e.show();
		
		
		///
		employee ee = new employee(e1);
		
		
		
		
	}

}
