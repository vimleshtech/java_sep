package compute;

public class Keys {

	public static String country="US";
	
}
