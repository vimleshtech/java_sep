package compute;

import java.util.Scanner;

public class employee {

	
	//data member or global variable 
	//default access specifier is public 
	int eid;
	String ename;
	int sal;
	int ysal;
	double tax;
	int slab1,slab2,slab3;
	
	//constructor 
	employee()
	{
		slab1= 300000;
		slab2= 500000;
		slab3= 1000000;
		
	}
	//constructor with parameter	
	employee(String country)
	{
		if(country.equals("US"))
		{
			slab1= 500000;
			slab2= 1000000;
			slab3= 2000000;	
		}
		else if(country.equals("UK"))
		{
			slab1= 700000;
			slab2= 1100000;
			slab3= 2200000;
			
		}
	}
	//copy constructor 
	employee(employee e)
	{	
		tax = e.tax;
		
	}
	
	//functions 
	public void newEmployee()
	{
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter eid ");
		eid = sc.nextInt(); //read number value 
		
		System.out.println("enter name :");
		ename = sc.next();  //read first word from string 
		//sc.nextLine()   - read all the words 
	
		System.out.println("enter sal : ");
		sal = sc.nextInt();
		
		
	}
	
	public void compute()
	{
		ysal= sal*12;
		
	}
	public void taxCalc()
	{
		if(ysal<slab1)
		{
			tax +=0;
		}
		else if(ysal<slab2)
		{
			tax += (ysal-slab1)*.05;
		}
		else if(ysal <slab3)
		{
			tax += slab1*.05+(ysal-slab2)*.20;
		}
		else
		{
			tax += slab1*.05+slab2*.20+(ysal-slab3)*.30;
		}
	}
	public void show()
	{
		System.out.println("Information ....");
		System.out.println("eid : "+eid);
		System.out.println("name : "+ename);
		System.out.println("sal: "+sal);
		System.out.println("ysal : "+ysal);
		System.out.println("tax : "+tax);
	}
	
}
