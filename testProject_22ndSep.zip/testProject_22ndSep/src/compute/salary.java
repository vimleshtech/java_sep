package compute;

public class salary {

}
