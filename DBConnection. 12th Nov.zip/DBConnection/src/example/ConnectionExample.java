package example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ConnectionExample {

	public static void writedata()
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			String name;
			int id;
			System.out.println("enter id : ");
			id = sc.nextInt();
			System.out.println("enter name :");
			name = sc.next();
			
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/hrms","root","root");
			//PreparedStatement st = con.prepareStatement("insert into users(uid,name) values(2,'jatin');");
			PreparedStatement st = con.prepareStatement("insert into users(uid,name) values(?,?);");
			st.setInt(1, id);
			st.setString(2, name);
			st.executeUpdate(); //insert, update, delete 
			System.out.println("data is saved");
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	public static void readdata() {
		try
		{
			
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/hrms","root","root");
			//PreparedStatement st = con.prepareStatement("insert into users(uid,name) values(2,'jatin');");
			PreparedStatement st = con.prepareStatement("select * from users");
			ResultSet rs = st.executeQuery();//select
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"\t"+rs.getString(2));
			}
			
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//writedata();
		readdata();
		
	}

}
