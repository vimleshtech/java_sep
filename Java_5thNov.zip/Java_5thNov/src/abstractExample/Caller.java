package abstractExample;

public class Caller {

	public static void main(String[] args) {

		//instance cannnot be created of abstract class
		//Sample s =new Sample();
		
		ExtendedClass e =new ExtendedClass();
		e.add();
		e.sub(33, 33);
		

	}

}
