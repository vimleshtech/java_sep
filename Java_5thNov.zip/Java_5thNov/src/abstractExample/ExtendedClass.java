package abstractExample;

public class ExtendedClass extends Sample {

	@Override
	void add() {
	
		int a,b,c;
		a=33;
		b =44;
		c =a+b;
		System.out.println(c);
	}
	
}
