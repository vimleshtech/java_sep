package abstractExample;

public abstract class Sample {

	//abstract method which cannot be implemented in same class
	abstract void add();
	//non-abstract method which must be implemented in same class
	void sub(int a, int b)
	{
		int c=a-b;
		System.out.println(c);
	}	
}
