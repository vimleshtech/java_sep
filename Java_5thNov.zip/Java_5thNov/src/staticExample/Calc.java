package staticExample;

public class Calc {

	int a;
	static int b;
	
	
}
