package staticExample;

public class Caller {

	public static void main(String[] args) {
		
		Calc.b =1;
		//Calc.a =33; //cannot be access without objec
		
		System.out.println(Calc.b);

		
		//
		Calc o1 =new Calc();
		Calc o2 =new Calc();
		o1.a =1;
		o1.b =1;
		
		
		o2.a =2;
		o2.b =2;
		
		System.out.println(o1.a);
		System.out.println(o1.b);
		
		System.out.println(o2.a);
		System.out.println(o2.b);
		
	}

}
