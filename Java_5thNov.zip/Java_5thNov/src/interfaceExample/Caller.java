package interfaceExample;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ExtendedClass e=new ExtendedClass();
		e.add(11,3);
		
	}

}
