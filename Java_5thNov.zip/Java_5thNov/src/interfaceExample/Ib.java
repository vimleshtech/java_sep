package interfaceExample;

public interface Ib {

	void tax(int sal);
	
}
