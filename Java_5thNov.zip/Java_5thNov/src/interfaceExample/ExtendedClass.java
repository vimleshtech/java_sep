package interfaceExample;

public class ExtendedClass implements Ia,Ib {

	int a;
	final int d=10;
	
	@Override
	public  void tax(int sal) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		
		this.a=a+b;
		
		System.out.println(a);

		if(a>d)
		{
			
		}
		
	}

	void show()
	{
		System.out.println(a);
	}
	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}


}
